import java.io.*;
import java.net.*;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.function.*;
import java.util.stream.*;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;

public final class JExpress {

  public sealed interface Request {
    String method();
    String path();
    String get(String header);
    String param(String name);
    List<Object> bodyArray() throws IOException;
    Map<String, Object> bodyObject() throws IOException;
    InputStream bodyStream();
    String bodyText() throws IOException;
  }

  public sealed interface Response {
    Response status(int status);
    Response append(String field, String value);
    Response set(String field, String value);
    Response type(String type);

    default Response type(String type, String charset) {
      return type(type + "; charset=" + charset);
    }

    default Response type(String type, Charset charset) {
      return type(type, charset.name());
    }

    void json(Object object) throws IOException;
    void json(String json) throws IOException;
    void send(String body) throws IOException;
    void sendFile(Path path) throws IOException;
  }

  @FunctionalInterface
  public interface Handler {
    @FunctionalInterface
    interface Chain {
      void next() throws IOException;
    }
    void handle(Request request, Response response, Chain chain) throws IOException;
  }

  @FunctionalInterface
  public interface Callback {
    void accept(Request request, Response response) throws IOException;
  }

  public interface Server extends AutoCloseable {
    void close();
  }

  private record RequestImpl(HttpExchange exchange, String[] components) implements Request {

    public String method() {
      return exchange.getRequestMethod().toUpperCase(Locale.ROOT);
    }

    public String path() {
      return exchange.getRequestURI().getPath();
    }

    public String get(String header) {
      return exchange.getRequestHeaders().getFirst(header);
    }

    @SuppressWarnings("unchecked")
    public String param(String name) {
      Object p = exchange.getAttribute("params");
      if (p == null) return "";
      return ((Map<String, String>) p).getOrDefault(name, "");
    }

    public InputStream bodyStream() {
      return exchange.getRequestBody();
    }

    private Object body() throws IOException {
      String ct = get("Content-Type");
      if (ct == null) throw new IllegalStateException();
      String mime = ct.split(";", 2)[0].trim().toLowerCase(Locale.ROOT);
      if (!"application/json".equals(mime)) throw new IllegalStateException();
      return ToyJSONParser.parse(bodyText());
    }

    @SuppressWarnings("unchecked")
    public Map<String, Object> bodyObject() throws IOException {
      return (Map<String, Object>) body();
    }

    @SuppressWarnings("unchecked")
    public List<Object> bodyArray() throws IOException {
      return (List<Object>) body();
    }

    public String bodyText() throws IOException {
      try (BufferedReader r = new BufferedReader(
          new InputStreamReader(bodyStream(), StandardCharsets.UTF_8))) {
        return r.lines().collect(Collectors.joining("\n"));
      }
    }
  }

  private record ResponseImpl(HttpExchange exchange) implements Response {

    public Response status(int status) {
      exchange.setAttribute("status", status);
      return this;
    }

    public Response append(String field, String value) {
      exchange.getResponseHeaders().add(field, value);
      return this;
    }

    public Response set(String field, String value) {
      exchange.getResponseHeaders().set(field, value);
      return this;
    }

    public Response type(String type) {
      return set("Content-Type", type);
    }

    public void json(Object object) throws IOException {
      json(JSONPrettyPrinter.toJSON(object));
    }

    public void json(String json) throws IOException {
      type("application/json", "utf-8");
      send(json);
    }

    public void send(String body) throws IOException {
      byte[] content = body.getBytes(StandardCharsets.UTF_8);
      Object st = exchange.getAttribute("status");
      int status = (st instanceof Integer i) ? i : 200;
      exchange.sendResponseHeaders(status, content.length);
      try (OutputStream out = exchange.getResponseBody()) {
        out.write(content);
      }
    }

    public void sendFile(Path path) throws IOException {
      if (!Files.exists(path)) {
        status(404).send("<h2>Not Found</h2>");
        return;
      }
      String ct = Files.probeContentType(path);
      if (ct == null) ct = "application/octet-stream";
      type(ct);
      exchange.sendResponseHeaders(200, Files.size(path));
      try (OutputStream out = exchange.getResponseBody()) {
        Files.copy(path, out);
      }
    }
  }

  private static Function<String[], Optional<Map<String, String>>> matcher(String uri) {
    String[] parts = uri.split("/");
    Predicate<String[]> pred = c -> c.length >= parts.length;
    BiConsumer<String[], Map<String, String>> cons = (a, b) -> {};

    for (int i = 0; i < parts.length; i++) {
      int idx = i;
      String p = parts[i];
      if (p.startsWith(":")) {
        String key = p.substring(1);
        BiConsumer<String[], Map<String, String>> old = cons;
        cons = (c, m) -> {
          old.accept(c, m);
          m.put(key, c[idx]);
        };
      } else {
        pred = pred.and(c -> p.equals(c[idx]));
      }
    }

    Predicate<String[]> fp = pred;
    BiConsumer<String[], Map<String, String>> fc = cons;
    return c -> {
      if (!fp.test(c)) return Optional.empty();
      Map<String, String> m = new HashMap<>();
      fc.accept(c, m);
      return Optional.of(m);
    };
  }

  private interface Pipeline {
    void accept(RequestImpl req, ResponseImpl res) throws IOException;
  }

  private Pipeline pipeline = (r, s) -> s.status(404).send("<h2>No route matched</h2>");

  public static JExpress express() {
    return new JExpress();
  }

  public void get(String path, Callback cb) {
    use(path, (req, res, chain) -> {
      if (req.method().equals("GET")) cb.accept(req, res);
      else chain.next();
    });
  }

  public void use(String path, Handler h) {
    Pipeline old = pipeline;
    Function<String[], Optional<Map<String, String>>> match = matcher(path);
    pipeline = (req, res) -> {
      Optional<Map<String, String>> p = match.apply(req.components);
      if (p.isPresent()) {
        req.exchange.setAttribute("params", p.get());
        h.handle(req, res, () -> old.accept(req, res));
      } else {
        old.accept(req, res);
      }
    };
  }

  public static Handler staticFiles(Path root) {
    Path base = root.toAbsolutePath().normalize();
    return (req, res, chain) -> {
      String r = req.path();
      String rel = r.startsWith("/") ? r.substring(1) : r;
      if (rel.isEmpty()) rel = "index.html";
      Path target = base.resolve(rel).normalize();
      if (!target.startsWith(base)) {
        res.status(403).send("<h2>Forbidden</h2>");
        return;
      }
      res.sendFile(target);
    };
  }

  public Server listen(int port) {
    try {
      HttpServer s = HttpServer.create(new InetSocketAddress(port), 0);
      s.createContext("/", ex -> {
        ex.setAttribute("status", 200);
        pipeline.accept(
          new RequestImpl(ex, ex.getRequestURI().getPath().split("/")),
          new ResponseImpl(ex)
        );
      });
      s.start();
      return () -> s.stop(1);
    } catch (IOException e) {
      throw new UncheckedIOException(e);
    }
  }

  static class ToyJSONParser {
    static Object parse(String s) {
      return Map.of("raw", s);
    }
  }

  static class JSONPrettyPrinter {
    static String toJSON(Object o) {
      return String.valueOf(o);
    }
  }

  public static void main(String[] args) {
    JExpress app = express();
    app.use("/", staticFiles(Path.of(".")));
    app.listen(8080);
    System.out.println("Server running on http://localhost:8080");
  }
}
