// VARIABLES GLOBALES
// Carte Leaflet
let map;

// Position de l'utilisateur
let userPosition = null;

// Rayon de recherche en km
let rayonKm = 2;

// Cercle affichant le rayon autour de l'utilisateur
let userCircle = null;

// Données GeoJSON chargées
const dataRaw = {
    commissariats: null,
    hopitaux: null,
    gares: null,
    pharmacies: null
};

// Couches affichées sur la carte
const layers = {
    commissariats: null,
    hopitaux: null,
    gares: null,
    pharmacies: null
};

// État des filtres
const activeFilters = {
    commissariats: true,
    hopitaux: true,
    gares: true,
    pharmacies: true
};

// INITIALISATION CARTE

// Création de la carte centrée sur Paris
map = L.map("map").setView([48.8566, 2.3522], 13);

// Fond de carte OpenStreetMap
L.tileLayer("https://tile.openstreetmap.org/{z}/{x}/{y}.png", {
    attribution: "© OpenStreetMap"
}).addTo(map);

// ICONES

// Fonction pour créer une icône personnalisée
const makeIcon = url => L.icon({
    iconUrl: url,
    iconSize: [28, 28],
    iconAnchor: [14, 28]
});

// Icônes des différents lieux
const iconPolice = makeIcon("icones/police.png");
const iconHopital = makeIcon("icones/hopital.png");
const iconGare = makeIcon("icones/gare.png");
const iconPharmacie = makeIcon("icones/pharmacie.png");

// GEOLOCALISATION

// Récupération de la position utilisateur
navigator.geolocation.getCurrentPosition(
    pos => {
        userPosition = L.latLng(pos.coords.latitude, pos.coords.longitude);

        const iconUser = makeIcon("icones/vousetesici.png");

        // Marqueur utilisateur
        L.marker(userPosition, { icon: iconUser })
            .addTo(map)
            .bindPopup("Vous êtes ici");

        // Cercle de recherche
        userCircle = L.circle(userPosition, {
            radius: rayonKm * 1000,
            color: "blue",
            fillOpacity: 0.1
        }).addTo(map);

        // Chargement des données
        loadGeoJSON();
    },
    () => {
        alert("Géolocalisation désactivée");
        loadGeoJSON();
    }
);

// CHARGEMENT DONNÉES

// Charge tous les fichiers GeoJSON
async function loadGeoJSON() {
    try {
        const [c, h, g, p] = await Promise.all([
            fetch("donnees/commissariats.geojson").then(r => r.json()),
            fetch("donnees/etablissementshospitaliers.geojson").then(r => r.json()),
            fetch("donnees/gares.geojson").then(r => r.json()),
            fetch("donnees/pharmacies.geojson").then(r => r.json())
        ]);

        // Stockage des données
        dataRaw.commissariats = c;
        dataRaw.hopitaux = h;
        dataRaw.gares = g;
        dataRaw.pharmacies = p;

        rebuildLayers();
    } catch (err) {
        console.error(err);
        alert("Erreur chargement données");
    }
}

// OUTILS

// Vérifie si un point est dans le rayon choisi
const inRadius = latlng =>
    !userPosition || userPosition.distanceTo(latlng) <= rayonKm * 1000;

// Formate un numéro de téléphone
function formatTelephone(num) {
    const str = String(num).replace(/\D/g, "");
    if (str.length === 10)
        return str.replace(/(\d{2})(?=\d)/g, "$1 ");
    return num;
}

// POPUP

// Construit le contenu du popup
const makePopup = (type, props) => {
    let html = `<div style="font-family:Inter;font-size:13px">`;

    html += `<div style="font-weight:600">${type}</div>`;

    const nom = props.nom || props.name || props.rs || props.nomgar;
    if (nom) html += `<div>${nom}</div>`;

    const tel = props.telephone || props.tel || props.num_tel;
    if (tel)
        html += `<div>Téléphone : ${formatTelephone(tel)}</div>`;

    html += `</div>`;
    return html;
};

// RECONSTRUCTION DES COUCHES
function rebuildLayers() {

    // Slider de rayon
    const slider = document.getElementById("rayon-range");
    const label = document.getElementById("rayon-value");

    slider.addEventListener("input", e => {
        rayonKm = Number(e.target.value);
        label.textContent = rayonKm;

        if (userCircle)
            userCircle.setRadius(rayonKm * 1000);

        rebuildLayers();
    });

    // Suppression des anciennes couches
    Object.keys(layers).forEach(k => {
        if (layers[k]) map.removeLayer(layers[k]);
    });

    // Limite pour éviter trop de marqueurs
    let count = 0;
    const MAX_MARKERS = 400;

    // Création d'une couche filtrée
    const buildLayer = (data, icon, label) =>
        L.geoJSON(data, {
            pointToLayer: (f, latlng) => {
                if (!inRadius(latlng)) return;
                if (count >= MAX_MARKERS) return;

                count++;

                return L.marker(latlng, { icon })
                    .bindPopup(makePopup(label, f.properties));
            }
        });

    layers.commissariats = buildLayer(dataRaw.commissariats, iconPolice, "Commissariat");
    layers.hopitaux = buildLayer(dataRaw.hopitaux, iconHopital, "Hôpital");
    layers.gares = buildLayer(dataRaw.gares, iconGare, "Gare");
    layers.pharmacies = buildLayer(dataRaw.pharmacies, iconPharmacie, "Pharmacie");

    // Ajout des couches actives
    Object.keys(layers).forEach(k => {
        if (activeFilters[k]) layers[k].addTo(map);
    });

    // Mise à jour du compteur
    const counter = document.getElementById("result-count");
    if (counter) {
        counter.textContent =
            count === 0
                ? "Aucun lieu trouvé"
                : count + " lieux trouvés";
    }
}

// FILTRES

// Activation/désactivation des types de lieux
["commissariats","hopitaux","pharmacies","gares"]
.forEach(type => {
    document.getElementById("chk-" + type).onchange = e => {
        activeFilters[type] = e.target.checked;
        rebuildLayers();
    };
});

// LOCALISATION

// Recentre la carte sur l'utilisateur
document.getElementById("btn-locate").onclick = () => {
    if (userPosition)
        map.flyTo(userPosition, map.getZoom(), { duration: 1.5 });
};

// PANEL URGENCE

const emergencyFab = document.getElementById("emergency-fab");
const emergencyPanel = document.getElementById("emergency-panel");

// Affiche/masque le panneau
emergencyFab.onclick = () => {
    emergencyPanel.classList.toggle("hidden");
};

// Ferme le panneau
document.getElementById("close-emergency").onclick = () => {
    emergencyPanel.classList.add("hidden");
};

// Boutons d'appel urgence
document.querySelectorAll(".emergency-option").forEach(btn => {
    btn.onclick = () => callEmergency(btn.dataset.num);
});

// Lance un appel téléphonique
function callEmergency(number) {
    window.location.href = "tel:" + number;
}
